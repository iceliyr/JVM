# Micronaut Hello World REST App with GraalVM Enterprise

In this example, you will build and run a Micronaut "Hello World" REST application with 

- [GraalVM Enterprise in OCI Code Editor](https://github.com/oracle-devrel/oci-code-editor-samples/tree/main/java-samples/graalvmee-java-micronaut-hello-rest)
- [GraalVM Enterprise in OCI Cloud Shell](./README-Cloud-Shell.md)
