#!/usr/bin/env bash

set -ex

$JAVA_HOME/bin/node --jvm --polyglot server.js
