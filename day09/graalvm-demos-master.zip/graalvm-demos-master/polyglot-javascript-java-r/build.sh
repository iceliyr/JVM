#!/usr/bin/env bash
set -ex

npm install
