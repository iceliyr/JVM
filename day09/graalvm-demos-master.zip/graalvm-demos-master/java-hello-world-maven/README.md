# Java Hello World with GraalVM Enterprise

In this example, you will build and run a "Hello World" Java application with 

- [GraalVM Enterprise in OCI Code Editor](https://github.com/oracle-devrel/oci-code-editor-samples/tree/main/java-samples/graalvmee-java-hello-world)
- [GraalVM Enterprise in OCI Cloud Shell](./README-Cloud-Shell.md)
