#!/usr/bin/env bash
set -ex
mvn clean install
