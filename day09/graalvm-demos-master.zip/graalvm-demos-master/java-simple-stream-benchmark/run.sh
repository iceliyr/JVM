#!/usr/bin/env bash
set -xe

$JAVA_HOME/bin/java -jar target/benchmarks.jar
